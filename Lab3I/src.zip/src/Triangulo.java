import java.util.Arrays;
/**
 * Classe que extende do Poligono  e forma um Triangulo
 * @author (Rafael Lourenço - 79771)
 * @version (1.0.0 - 25/02/2024)
 */
public class Triangulo extends Poligono{
    private final Ponto[] pontosTriangulo;
    public Triangulo(Ponto[] pontos){
        super(pontos);
        if(!isTriangulo(pontos)){
            System.out.println("Triangulo:vi");
            System.exit(0);
        }
        this.pontosTriangulo = pontos;


    }
    /**
     * @param pontos array de pontos
     * @return true se o conjunto de pontos formar um triangulo, false se não
     */
    public boolean isTriangulo(Ponto[] pontos){
        if(pontos.length != 3) return false;
        if((pontos[0].dist(pontos[1]) + pontos[1].dist(pontos[2])) < pontos[2].dist(pontos[0]) || (pontos[0].dist(pontos[1]) + pontos[2].dist(pontos[0])) < pontos[1].dist(pontos[2]) || (pontos[1].dist(pontos[2]) + pontos[2].dist(pontos[0])) < pontos[0].dist(pontos[1])) return false;
        return true;
    }
    /**
     * @param rotAngle angulo de rotacao em graus
     * @param xP cordenada x do Ponto de rotação
     * @param yP cordenada y do Ponto de rotação
     * @return novo Triangulo rodado
     */
    public Triangulo rotate(int rotAngle, double xP, double yP){
        Ponto[] pontos = this.getPontosTriangulo();
        Triangulo novoPoligono;
        Ponto[] novosPontos = new Ponto[pontos.length];
        double angle = Math.toRadians(rotAngle);
        for (int i = 0; i < pontos.length; i++) {
            int x = (int) ( Math.round(xP +(((pontos[i].getX() - xP) * Math.cos(angle)) - ((pontos[i].getY() - yP) * Math.sin(angle)))));
            int y = (int) ( Math.round(yP +(((pontos[i].getX() - xP) * Math.sin(angle)) + ((pontos[i].getY() - yP) * Math.cos(angle)))));
            novosPontos[i] = new Ponto(x,y);
        }
        novoPoligono = new Triangulo(novosPontos);
        return novoPoligono;
    }
    /**
     * @param rotAngle angulo em graus
     * @return novo Triangulo rodado
     */
    public Triangulo rotate(int rotAngle){
        Triangulo novopoligono;
        Double[] ponto = calculateCentroide(pontosTriangulo);
        novopoligono = rotate(rotAngle,ponto[0],ponto[1]);
        return novopoligono;
    }
    /**
     * @return String formatada do Triangulo
     */
    @Override
    public String toString() {
        return "Triangulo: " + Arrays.toString(pontosTriangulo);
    }

    public Ponto[] getPontosTriangulo() {
        return pontosTriangulo;
    }
}
