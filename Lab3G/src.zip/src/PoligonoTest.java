import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

class PoligonoTest {
    @Test
    public void testPoligono1(){ // Teste para verificar se a funçao da false quando os polignos não se tocam


        Ponto[] pontos = new Ponto[4];
        pontos[0] = new Ponto(4,5);
        pontos[1] = new Ponto(8,5);
        pontos[2] = new Ponto(8,7);
        pontos[3] = new Ponto(5,7);
        Poligono p1 = new Poligono(pontos,pontos.length);

        Ponto[] pontos2 = new Ponto[4];
        pontos[0] = new Ponto(7,1);
        pontos[1] = new Ponto(9,1);
        pontos[2] = new Ponto(9,3);
        pontos[3] = new Ponto(7,3);
        Poligono p2 = new Poligono(pontos, pontos2.length);

        assertFalse(p1.Poligonosintersect(p2));

    }
    @Test
    public void testPoligono2(){ // Teste para verificar se a função de interseptar 2 poligonos está correta


        Ponto[] pontos = new Ponto[4];
        pontos[0] = new Ponto(5,5);
        pontos[1] = new Ponto(8,5);
        pontos[2] = new Ponto(8,7);
        pontos[3] = new Ponto(5,7);
        Poligono p1 = new Poligono(pontos,pontos.length);

        Ponto[] pontos2 = new Ponto[4];
        pontos[0] = new Ponto(7,4);
        pontos[1] = new Ponto(9,4);
        pontos[2] = new Ponto(9,6);
        pontos[3] = new Ponto(7,6);
        Poligono p2 = new Poligono(pontos, pontos2.length);

        assertTrue(p1.Poligonosintersect(p2));

    }

    @Test
    public void testPoligono3(){ // Teste para verificar se a funçao da false quando os polignos não se tocam


        Ponto[] pontos = new Ponto[4];
        pontos[0] = new Ponto(1,1);
        pontos[1] = new Ponto(4,2);
        pontos[2] = new Ponto(4,5);
        pontos[3] = new Ponto(2,3);
        Poligono p1 = new Poligono(pontos,pontos.length);

        Ponto[] pontos2 = new Ponto[3];
        pontos[0] = new Ponto(6,4);
        pontos[1] = new Ponto(7,2);
        pontos[2] = new Ponto(9,4);
        Poligono p2 = new Poligono(pontos, pontos2.length);

        assertFalse(p1.Poligonosintersect(p2));
    }
    @Test
    public void testPoligono4(){ //Teste para verificar se a função de interseptar 2 poligonos está correta
        Ponto[] pontos = new Ponto[4];
        pontos[0] = new Ponto(1,1);
        pontos[1] = new Ponto(4,2);
        pontos[2] = new Ponto(4,5);
        pontos[3] = new Ponto(2,3);
        Poligono p1 = new Poligono(pontos,pontos.length);

        Ponto[] pontos2 = new Ponto[3];
        pontos[0] = new Ponto(3,3);
        pontos[1] = new Ponto(7,2);
        pontos[2] = new Ponto(9,4);
        Poligono p2 = new Poligono(pontos, pontos2.length);

        assertTrue(p1.Poligonosintersect(p2));
    }
}