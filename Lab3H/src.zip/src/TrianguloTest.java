import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TrianguloTest {
    @Test
    public void testPositive() // Testa a função isTriangulo, para verificar se um conjunto de Pontos forma um triangulo
    {
        Ponto[] pontos = new Ponto[3];
        pontos[0] = new Ponto(1,0);
        pontos[1] = new Ponto(3,0);
        pontos[2] = new Ponto(2,2);
        Triangulo triangulo = new Triangulo(pontos);
        assertTrue(triangulo.isTriangulo(pontos));
    }

    @Test
    public void testNegative() // Testa a função isTriangulo, para verificar se um conjunto de Pontos não forma um triangulo
    {
        Ponto[] pontos = new Ponto[3];
        pontos[0] = new Ponto(1,0);
        pontos[1] = new Ponto(3,0);
        pontos[2] = new Ponto(2,0);
        Triangulo triangulo = new Triangulo(pontos);
        assertFalse(triangulo.isTriangulo(pontos));
        // Expected: Poligono:vi por conta da colinearidade
    }

    @Test
    public void testParaString() // Testa a função paraString, para verificar se o conjunto de pontos é corretamente printado
    {
        Ponto[] pontos = new Ponto[3];
        pontos[0] = new Ponto(1,0);
        pontos[1] = new Ponto(3,0);
        pontos[2] = new Ponto(2,2);
        Triangulo triangulo = new Triangulo(pontos);
        assertEquals("Triangulo: [(1,0), (3,0), (2,2)]",triangulo.toString());
        // Expected: Triangulo: [(1,0), (3,0), (2,2)]
    }



}